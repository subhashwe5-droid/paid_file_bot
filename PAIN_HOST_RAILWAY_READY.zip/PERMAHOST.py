"""
PA1N Host Bot v13 - Full Features / Runnable Edition
- Developer: @PA1Npy
- Features: Upload, Start/Stop/Restart/Delete, Logs, Admin Panel, Broadcast, Promote/Demote Users
- WARNING: Uploaded Python files can be executed if using real subprocess mode
"""

import os, json, time, subprocess
from datetime import datetime
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    ApplicationBuilder, CommandHandler, MessageHandler,
    CallbackQueryHandler, ContextTypes, filters
)

# ---------------- CONFIG ----------------
BOT_TOKEN = "8262057623:AAF9sJ478oDGTlDbFc_qowWe8gvGQNiG4eU"
OWNER_ID = 5840953778
DATA_DIR = "pain_data"
USERS_FILE = os.path.join(DATA_DIR, "users.json")
FILES_FILE = os.path.join(DATA_DIR, "files.json")
LOGS_FILE  = os.path.join(DATA_DIR, "logs.json")

# ---------------- INIT ----------------
for p in (DATA_DIR,):
    os.makedirs(p, exist_ok=True)

def ensure_json(path, default):
    if not os.path.exists(path):
        with open(path, "w") as f:
            json.dump(default, f, indent=2)
    else:
        try:
            with open(path) as f:
                data = json.load(f)
            if not isinstance(data, type(default)):
                raise ValueError
        except:
            with open(path, "w") as f:
                json.dump(default, f, indent=2)

ensure_json(USERS_FILE, {})
ensure_json(FILES_FILE, {})
ensure_json(LOGS_FILE, {})

# ---------------- HELPERS ----------------
def load_json(path):
    with open(path) as f: return json.load(f)

def save_json(path, data):
    with open(path, "w") as f: json.dump(data, f, indent=2)

def ensure_user_record(uid, name=None):
    users = load_json(USERS_FILE)
    s = str(uid)
    if s not in users or not isinstance(users[s], dict):
        users[s] = {"name": name or ("User"+s), "role": "normal", "created": int(time.time())}
        save_json(USERS_FILE, users)
    return users[s]

def get_role(uid):
    u = ensure_user_record(uid)
    return u.get("role", "normal")

def set_role(uid, role):
    users = load_json(USERS_FILE)
    users[str(uid)] = users.get(str(uid), {"name": str(uid), "created": int(time.time())})
    users[str(uid)]["role"] = role
    save_json(USERS_FILE, users)

def user_file_id(uid, filename): return f"{uid}__{filename}"

def add_file_record(owner_uid, filename, saved_path):
    files = load_json(FILES_FILE)
    fid = user_file_id(owner_uid, filename)
    files[fid] = {
        "owner": owner_uid,
        "filename": filename,
        "path": saved_path,
        "uploaded_at": int(time.time()),
        "status": "stopped",
        "started_at": None,
        "stdout": [],
        "stderr": []
    }
    save_json(FILES_FILE, files)
    return fid

def remove_file_record(fid):
    files = load_json(FILES_FILE)
    if fid in files: files.pop(fid); save_json(FILES_FILE, files)

def set_file_status(fid, status):
    files = load_json(FILES_FILE)
    if fid in files:
        files[fid]["status"] = status
        files[fid]["started_at"] = int(time.time()) if status=="running" else None
        save_json(FILES_FILE, files)

def add_log(fid, text):
    logs = load_json(LOGS_FILE)
    if fid not in logs: logs[fid]=[]
    logs[fid].append({"time": int(time.time()), "text": text})
    if len(logs[fid])>200: logs[fid]=logs[fid][-200:]
    save_json(LOGS_FILE, logs)

def format_ts(ts):
    if not ts: return "N/A"
    try: return datetime.utcfromtimestamp(int(ts)).strftime("%Y-%m-%d %H:%M:%S UTC")
    except: return "N/A"

# ---------------- UI ----------------
def main_menu_kb(uid):
    kb = [
        [InlineKeyboardButton("📂 My Bots", callback_data=f"myfiles|{uid}"),
         InlineKeyboardButton("💎 Upgrade", callback_data=f"upgrade|{uid}")],
        [InlineKeyboardButton("👨‍💻 Developer", url="https://t.me/PA1Npy"),
         InlineKeyboardButton("ℹ️ About", callback_data=f"about|{uid}")]
    ]
    if uid==OWNER_ID: kb.append([InlineKeyboardButton("⚙️ Admin Panel", callback_data=f"admin|{uid}")])
    return InlineKeyboardMarkup(kb)

def file_control_kb(fid):
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("▶️ Start", callback_data=f"start|{fid}"),
         InlineKeyboardButton("⏹ Stop", callback_data=f"stop|{fid}")],
        [InlineKeyboardButton("🔁 Restart", callback_data=f"restart|{fid}"),
         InlineKeyboardButton("🗑 Delete", callback_data=f"delete|{fid}")],
        [InlineKeyboardButton("📂 Info", callback_data=f"info|{fid}"),
         InlineKeyboardButton("🧾 Logs", callback_data=f"logs|{fid}")]
    ])

def admin_panel_kb():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📊 Stats", callback_data="admin_stats"),
         InlineKeyboardButton("📣 Broadcast", callback_data="admin_broadcast")],
        [InlineKeyboardButton("👥 Manage Users", callback_data="admin_users"),
         InlineKeyboardButton("📁 All Files", callback_data="admin_files")],
        [InlineKeyboardButton("⬅️ Back", callback_data=f"about|{OWNER_ID}")]
    ])

# ---------------- RUNNING PROCESSES ----------------
RUNNING_PROCESSES = {}  # fid -> subprocess.Popen

# ---------------- HANDLERS ----------------
async def start_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    ensure_user_record(user.id, user.first_name)
    text = (
         f"🌌 𝓦𝓮𝓵𝓬𝓸𝓶𝓮 𝓽𝓸 𝓟𝓐1𝓝 𝐇𝐨𝐬𝐭 𝐒𝐲𝐬𝐭𝐞𝐦 v13! 🌌\n\n"
        f"🙋‍♂️ User: [{user.first_name}](tg://user?id={user.id})\n"
        f"🆔 Chat ID: `{user.id}`\n\n"
        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
        "✨ 𝓨𝓸𝓾 𝓬𝓪𝓷 𝓶𝓪𝓷𝓪𝓰𝓮 𝔂𝓸𝓾𝓻 𝓟𝔂𝓽𝓱𝓸𝓷 (.py) 𝓯𝓲𝓵𝓮𝓼 𝓮𝓪𝓼𝓲𝓵𝔂 ✨\n\n"
        "💻 𝓕𝓮𝓪𝓽𝓾𝓻𝓮𝓼:\n"
        "• 𝓤𝓹𝓵𝓸𝓪𝓭 𝓪𝓷𝓭 𝓼𝓪𝓿𝓮 𝓕𝓲𝓵𝓮𝓼\n"
        "• 𝓢𝓽𝓪𝓻𝓽 / 𝓢𝓽𝓸𝓹 / 𝓡𝓮𝓼𝓽𝓪𝓻𝓽 / 𝓓𝓮𝓵𝓮𝓽𝓮\n"
        "• 𝓥𝓲𝓮𝔀 𝓕𝓲𝓵𝓮 𝓘𝓷𝓯𝓸 & 𝓛𝓸𝓰𝓼\n"
        "• 𝓐𝓭𝓶𝓲𝓷 𝓟𝓪𝓷𝓮𝓵 (𝓞𝔀𝓷𝓮𝓻 𝓸𝓷𝓵𝔂)\n\n"
        "💎 𝓤𝓹𝓵𝓸𝓪𝓭 𝓛𝓲𝓶𝓲𝓽𝓼:\n"
        "• Normal: 2 files\n"
        "• Premium: 15 files\n"
        "• Owner: Unlimited\n\n"
        "👨‍💻 Developer: @PA1Npy\n"
        "📌 Note: This is a safe demo. Files will NOT be executed here.\n"
        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
        "⬇️ Use buttons below to navigate the panel ⬇️"
    )

    await update.message.reply_text(text, parse_mode="Markdown", reply_markup=main_menu_kb(user.id))

async def upload_file_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.message.document:
        await update.message.reply_text("❌ Please send a .py file.")
        return
    doc = update.message.document
    user = update.effective_user
    ensure_user_record(user.id, user.first_name)
    role = get_role(user.id)
    files = load_json(FILES_FILE)
    user_files = [f for f in files.values() if f["owner"]==user.id]
    limit = 9999 if role=="owner" else 15 if role=="premium" else 2
    if len(user_files)>=limit:
        await update.message.reply_text(f"⚠️ Limit reached ({limit})")
        return
    if not doc.file_name.endswith(".py"):
        await update.message.reply_text("⚠️ Only .py allowed.")
        return
    save_path = os.path.join(DATA_DIR,f"{user.id}_{int(time.time())}_{doc.file_name}")
    tgfile = await doc.get_file()
    await tgfile.download_to_drive(save_path)
    fid = add_file_record(user.id, doc.file_name, save_path)
    add_log(fid, f"Uploaded by {user.id}")
    await update.message.reply_text(
        f"✅ Saved `{doc.file_name}`\nID: `{fid}`", parse_mode="Markdown",
        reply_markup=file_control_kb(fid)
    )

# ---------------- CALLBACKS ----------------
async def callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query; await q.answer(); data = q.data
    uid = q.from_user.id

    # --- ADMIN FIRST ---
    admin_callbacks = ["admin_stats","admin_broadcast","admin_users","admin_files","admin_promote","admin_demote"]
    if data.startswith("admin|") or data in admin_callbacks:
        if uid!=OWNER_ID: await q.message.reply_text("⛔ Only owner"); return
        # Admin panel display
        if data.startswith("admin|"):
            await q.message.reply_text("⚙️ Admin Panel", reply_markup=admin_panel_kb())
            return
        if data=="admin_stats":
            users = load_json(USERS_FILE); files = load_json(FILES_FILE)
            total = len(users); prem=sum(1 for u in users.values() if u.get("role")=="premium")
            normal=sum(1 for u in users.values() if u.get("role")=="normal"); total_files=len(files)
            await q.message.reply_text(f"📊 Stats\nUsers:{total}\nPremium:{prem}\nNormal:{normal}\nFiles:{total_files}")
            return
        if data=="admin_broadcast":
            await q.message.reply_text("✉️ Send broadcast text now.")
            context.user_data["mode"]="broadcast"; return
        if data=="admin_users":
            users = load_json(USERS_FILE); msg="👥 Users:\n"
            for uid2,info in users.items(): msg+=f"`{uid2}` — {info.get('name','-')} ({info.get('role','normal')})\n"
            kb=InlineKeyboardMarkup([
                [InlineKeyboardButton("💎 Promote",callback_data="admin_promote"),
                 InlineKeyboardButton("⬇️ Demote",callback_data="admin_demote")],
                [InlineKeyboardButton("⬅️ Back",callback_data=f"admin|{OWNER_ID}")]
            ])
            await q.message.reply_text(msg,parse_mode="Markdown",reply_markup=kb)
            return
        if data=="admin_files":
            files=load_json(FILES_FILE)
            if not files: await q.message.reply_text("📂 No files"); return
            msg="📁 All Files:\n"
            for fid,meta in files.items(): msg+=f"`{fid}` — {meta['filename']} (owner:{meta['owner']}) status:{meta['status']}\n"
            await q.message.reply_text(msg,parse_mode="Markdown"); return
        if data in ["admin_promote","admin_demote"]:
            context.user_data["mode"]="promote" if data=="admin_promote" else "demote"
            await q.message.reply_text("📨 Send chat ID to change role"); return

    # --- FILE CONTROL ---
    if "|" in data:
        cmd,fid = data.split("|",1); files=load_json(FILES_FILE)
        if fid not in files: await q.message.reply_text("⚠️ File record not found"); return
        meta=files[fid]; owner=meta["owner"]
        if uid!=owner and uid!=OWNER_ID: await q.message.reply_text("⛔ Only owner/file owner"); return

        if cmd=="start":
            if fid in RUNNING_PROCESSES: await q.message.reply_text("⚠️ Already running"); return
            proc=subprocess.Popen(["python3",meta["path"]],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
            RUNNING_PROCESSES[fid]=proc; set_file_status(fid,"running"); add_log(fid,f"Started by {uid}")
            await q.message.reply_text(f"▶️ `{meta['filename']}` running",parse_mode="Markdown"); return
        if cmd=="stop":
            proc=RUNNING_PROCESSES.pop(fid,None)
            if proc: proc.terminate()
            set_file_status(fid,"stopped"); add_log(fid,f"Stopped by {uid}")
            await q.message.reply_text(f"⏹ `{meta['filename']}` stopped",parse_mode="Markdown"); return
        if cmd=="restart":
            proc=RUNNING_PROCESSES.pop(fid,None)
            if proc: proc.terminate()
            proc=subprocess.Popen(["python3",meta["path"]],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
            RUNNING_PROCESSES[fid]=proc; set_file_status(fid,"running"); add_log(fid,f"Restarted by {uid}")
            await q.message.reply_text(f"🔁 `{meta['filename']}` restarted",parse_mode="Markdown"); return
        if cmd=="delete":
            proc=RUNNING_PROCESSES.pop(fid,None); 
            if proc: proc.terminate()
            if os.path.exists(meta["path"]): os.remove(meta["path"])
            remove_file_record(fid); add_log(fid,f"Deleted by {uid}")
            await q.message.reply_text(f"🗑 `{meta['filename']}` deleted"); return
        if cmd=="info":
            started=format_ts(meta.get("started_at")); await q.message.reply_text(
                f"📄 Info `{meta['filename']}`\n• File ID:{fid}\n• Owner:{owner}\n• Status:{meta['status']}\n• Uploaded:{format_ts(meta['uploaded_at'])}\n• Last started:{started}",
                parse_mode="Markdown"); return
        if cmd=="logs":
            logs=load_json(LOGS_FILE).get(fid,[])
            if not logs: await q.message.reply_text("🧾 No logs"); return
            text="🧾 Logs (latest first):\n"
            for e in logs[-30:][::-1]: text+=f"{format_ts(e['time'])}: {e['text']}\n"
            await q.message.reply_text(text); return

    # --- OTHER ---
    if data.startswith("myfiles|"):
        uid2=int(data.split("|",1)[1]); files=load_json(FILES_FILE)
        user_files=[(fid,meta) for fid,meta in files.items() if meta["owner"]==uid2]
        if not user_files: await q.message.reply_text("📂 No uploaded files"); return
        msg="📂 Your Files:\n"
        for fid,meta in user_files: msg+=f"`{fid}` — {meta['filename']} (status:{meta['status']})\n"
        await q.message.reply_text(msg,parse_mode="Markdown"); return
    if data.startswith("upgrade|"): await q.message.reply_text("💎 Contact @PA1Npy"); return
    if data.startswith("about|"): await start_handler(update, context); return
    await q.message.reply_text("⚠️ Unknown action")

# ---------------- TEXT MODE (broadcast/promote) ----------------
async def text_mode_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user=update.effective_user; mode=context.user_data.get("mode")
    if not mode: await update.message.reply_text("ℹ️ Send /start"); return
    if mode=="broadcast":
        if user.id!=OWNER_ID: await update.message.reply_text("⛔ Only owner"); context.user_data.pop("mode",None); return
        txt=update.message.text; users=load_json(USERS_FILE)
        count=0
        for uid in users.keys():
            try: await context.bot.send_message(int(uid), f"📢 Broadcast:\n\n{txt}"); count+=1
            except: continue
        await update.message.reply_text(f"✅ Broadcast sent to ~{count} users"); context.user_data.pop("mode",None); return
    if mode in ("promote","demote"):
        if user.id!=OWNER_ID: await update.message.reply_text("⛔ Only owner"); context.user_data.pop("mode",None); return
        try: target=int(update.message.text.strip())
        except: await update.message.reply_text("❌ Invalid ID"); context.user_data.pop("mode",None); return
        if mode=="promote": set_role(target,"premium"); await update.message.reply_text(f"✅ {target} promoted to PREMIUM")
        else: set_role(target,"normal"); await update.message.reply_text(f"✅ {target} demoted to NORMAL")
        context.user_data.pop("mode",None); return
    await update.message.reply_text("⚠️ Unknown mode"); context.user_data.pop("mode",None)

# ---------------- MAIN ----------------
def main():
    app=ApplicationBuilder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start",start_handler))
    app.add_handler(MessageHandler(filters.Document.ALL,upload_file_handler))
    app.add_handler(CallbackQueryHandler(callback_handler))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND,text_mode_handler))
    print("🤖 PA1N Host Bot v13 Full Features Running...")
    app.run_polling()

if __name__=="__main__": main()